.. cheatsheet documentation master file, created by
   sphinx-quickstart on Fri Jul  2 21:28:26 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Projet Vuvuzela
===============


.. toctree::
   :caption: Table des matières
   :maxdepth: 1

   getting_started/index
   
