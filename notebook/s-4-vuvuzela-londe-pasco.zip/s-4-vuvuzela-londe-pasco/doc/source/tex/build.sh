OUTPUT_PDF="../_static/pdf"
OUTPUT_SVG="../svg"

for i in `find . -name "*.tex" -type f`; do
    echo "process $i"
    pdflatex -output-directory=$OUTPUT_PDF $i 
    
done

cd $OUTPUT_PDF

for i in `find . -name "*.pdf" -type f`; do
    echo "convert pdf file $i"
    output_file="$OUTPUT_SVG/$(basename ${i%.*}.svg)"
    pdf2svg $i $output_file
done

echo "delete temporary file"
rm *.aux
rm *.log