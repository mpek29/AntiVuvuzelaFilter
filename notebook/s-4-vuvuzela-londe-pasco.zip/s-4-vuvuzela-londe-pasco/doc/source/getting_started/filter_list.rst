Liste des filtres rejecteurs
----------------------------

Filtres Passifs
+++++++++++++++

* Filtre RLC

.. figure:: ../_static/svg/RLC.svg
   :alt: RLC

   Filtre RLC Notch

* Filtre Twin T

.. figure:: ../_static/svg/twin_T.svg
   :alt: RLC

   Filtre Twin-T

Filtres Actifs
++++++++++++++

* Filtre Twin T Actif: https://www.analog.com/media/en/training-seminars/tutorials/MT-225.pdf
* Filtre Bainter Actif: https://www.analog.com/media/en/training-seminars/tutorials/MT-203.pdf