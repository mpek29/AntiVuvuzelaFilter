Cheatsheet
==========

Utilisation de Gitlab 
---------------------

Cloner localement un repo
+++++++++++++++++++++++++

* Dans un terminal Anaconda prompt, déplacez-vous dans un répertoire où vous souhaitez cloner votre repo.
* Cloner votre repo en utilisant la commande suivante :

.. code ::

    $ git clone https://git.enib.fr/{{username}}/{{repo_name}}.git

Les paramètres username et repo_name doivent être remplacés par votre username et par le nom de votre repo gitlab.

Pousser un repo 
+++++++++++++++

Pour rapatrier vos codes sur gitlab, il faut effectuer les opérations suivantes.

* Dans un terminal Anaconda prompt, déplacez-vous dans le répertoire que vous avez cloné.
* Pousser vos modifications en utilisant les commandes suivantes:

.. code ::

    $ git add .
    $ git commit -m "mes modifications"
    $ git push -u origin master

Utilisation de Python
---------------------

Charger un fichier son
++++++++++++++++++++++

* Documentation: https://docs.scipy.org/doc/scipy/reference/generated/scipy.io.wavfile.read.html

.. code ::

    from scipy.io import wavfile

    Fs, data = wavfile.read("mon_fichier_audio.wav")

Afficher un spectre 
+++++++++++++++++++

* Documentation : https://matplotlib.org/stable/gallery/lines_bars_and_markers/spectrum_demo.html


.. code ::

    import matplotlib.pyplot as plt

    ...

    plt.magnitude_spectrum(data, Fs=Fs)

Jouer un fichier son sous Jupyter
+++++++++++++++++++++++++++++++++

* Documentation: https://ipython.org/ipython-doc/2/api/generated/IPython.lib.display.html#IPython.lib.display.Audio

.. code ::

    import IPython.display as ipd
    
    ipd.Audio('audio/conga_groove.wav')

Il est également possible de passer un tableau numpy à l'objet :code:`Audio`.

.. code ::

    import numpy as np
    import IPython.display as ipd

    Fs = 22050 # sample rate
    t = np.arange(0, 1, 1/Fs)
    x = 0.5*np.sin(2*np.pi*440*t)  
    ipd.Audio(x, rate=Fs)  