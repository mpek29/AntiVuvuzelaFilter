Description
===========

.. |uncheck_| raw:: html

    <input type="checkbox">

Lors de la coupe du Monde de Football 2010 (et de rugby de 1995), les téléspectateurs du monde entier ont pu découvrir un instrument de musique d’Afrique du Sud nommé le Vuvuzela. 
Lors de la diffusion des matchs, le son continu produit par cet instrument est rapidement devenu gênant.
(exemple: https://www.youtube.com/watch?v=bKCIFXqhLzo). 

Dans ce projet, vous allez mettre en place un filtre "anti-vuvuzela" pour atténuer les sonorités de cet instrument
et améliorer la restitution audio des commentaires sportifs. Le fichier son à traiter est disponible dans le repertoire `wav`.

.. raw:: html

   <audio controls="controls">
         <source src="../../../../wav/vuvuzela.wav" type="audio/wav">
         Your browser does not support the <code>audio</code> element. 
   </audio>


Déroulement du Projet 
---------------------

* Projet en binôme exclusivement, 
* Volume Horaire: 3*2UCs (dont 3UCs désencadrées).


Crtières d'évaluations
----------------------

Le projet sera évalué aussi bien sur la forme (présentation) que sur le fond (aspects techniques).

Forme
+++++

* |uncheck_| Qualité de la restitution 

    * qualité de la présentation,
    * organisation du projet, 
    * équilibre du contenu, 
    * qualité des fichiers fournis (Ltspice, Python),
    * sobriété numérique / confidentialité numérique (pas de Gitlab en public ou internal),
    * qualité de la conclusion.


* |uncheck_| Originalité du travail technique

    * qualité de la démarche technique et scientifique,
    * originalité de la solution proposée,
    * utilisation raisonnée des outils (python, ltpsice, oscillo, ...)
    * qualité des résultats sonores obtenus.


Fond
++++

* |uncheck_| Analyses du fichier sonore wav (temporel / fréquentiel),
* |uncheck_| Prototypage/implémentation/intégration des différents filtres.
* |uncheck_| Tests des différentes solutions en validant les performances et en évaluant gains et pertes du choix.




