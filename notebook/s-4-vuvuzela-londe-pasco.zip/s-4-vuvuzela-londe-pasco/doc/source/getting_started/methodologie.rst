Methodologie
============

Demarche recommandée
--------------------

En première approximation, un son de vuvuzela peut être modélisé mathématiquement comme une somme de :math:`L` sinusoïdes dans du bruit

.. math ::

    s(t) = \sum_{l=1}^{L} a_l \sin(2\pi f_l t+\varphi_l) + b(t).


Pour supprimer le son de vuvuzela, une solution possible consiste à cascader :math:`L` filtres rejecteur d'ordre 2.  L'objectif de chaque rejecteur est
de supprimer une composante fréquentielle :math:`f_l` particulière.

Pour implementer cette cascade de filtres, il est recommandé d'utiliser la stratégie suivante :

* Analyse du fichier sonore `vuvuzela.wav`
    * Détermination du nombre :math:`L` de composantes sinusoïdales significatives,
    * Détermination des fréquences :math:`f_l`,
    * Détermination approximative de :math:`m`.

* Mise en oeuvre du filtre
    * Choix d'une topologie de filtre rejecteur,
    * détermination des composants électroniques.


