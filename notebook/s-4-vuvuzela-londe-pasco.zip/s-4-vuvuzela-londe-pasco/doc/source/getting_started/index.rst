Getting Started
===============


.. toctree::
   :caption: Table des matières
   :maxdepth: 1

   description
   methodologie
   filter_list
   cheatsheet
   
