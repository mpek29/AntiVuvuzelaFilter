# S4 Vuvuzela PASCO LONDE

## What is that ?
This is the project directory on the Vuvuzela of LONDE and PASCO.

## Documentation

* Description du projet: `/doc/build/html/index.html`

## Contenu du repo 

* `/doc`: répertoire contenant la documentation,
* `/src`: répertoire contenant du code Python,
* `/asc`: répertoire contenant les fichiers ltspice,
* `/wav`: répertoire contenant les fichiers audios (notamment le fichier `vuvuzela.wav`)
